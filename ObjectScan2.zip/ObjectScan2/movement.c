/*
 * movement.c
 *
 *  Created on: Feb 9, 2021
 *      Author: jmhafele
 */

#include "movement.h"

double move_forward(oi_t *sensor_data, double distance_mm){

    double sum = 0;
    oi_setWheels(250,250);
    while(sum < distance_mm){
        oi_update(sensor_data);
        sum += sensor_data -> distance;//use -> notation since pointer

        if(check_sensors(sensor_data)){ //Checks if robot had collision on either bumper
            oi_setWheels(0,0); //Stop
            move_backward(sensor_data, sum); //backs up, states specific checkpoint unreachable
            return sum;
        }
    }
    oi_setWheels(0,0); //Stop
    lcd_printf("distance = %.2f meters", sum/1000); //Prints distance
    return sum;
}

double turn_right(oi_t *sensor, double degrees){
    double angle = 0;
    oi_setWheels(50,-50);
    while(angle < degrees - 1.4){
        oi_update(sensor);
        angle += sensor -> angle;
    }
    oi_setWheels(0,0); //Stop
    return angle;
}

double turn_left(oi_t *sensor, double degrees){
    double angle = 0;
    oi_setWheels(-50,50);
    while(angle > -degrees + 1.4){
        oi_update(sensor);
        angle += sensor -> angle;
    }
    oi_setWheels(0,0); //Stop
    return angle;
}

double move_backward(oi_t *sensor_data, double distance_mm){

    double sum = 0;

    oi_setWheels(-250,-250);

    while(sum > -distance_mm){
        oi_update(sensor_data);
        sum += sensor_data -> distance;//use -> notation since pointer
    }

    oi_setWheels(0,0); //Stop
    lcd_printf("distance = %.2f meters", sum/1000); //Prints distance
    return sum;
}

int check_sensors(oi_t *sensor_data){
    if(sensor_data -> bumpRight){
        lcd_printf("bumpRight \ndetected");
        return 1;
    }
    else if(sensor_data -> bumpLeft){
        lcd_printf("bumpLeft \ndetected");
        return 2;
    }
    else if(sensor_data -> cliffRightSignal == 0){
        lcd_printf("cliffRightSignal \nPitfall \ndetected");
        return 3;
    }
    else if(sensor_data -> cliffRightSignal > 1000){
        lcd_printf("cliffRightSignal \nBorder \ndetected");
        return 4;
    }
    else if(sensor_data -> cliffLeftSignal == 0){
        lcd_printf("cliffLeftSignal \nPitfall \ndetected");
        return 5;
    }
    else if(sensor_data -> cliffLeftSignal > 1000){
        lcd_printf("cliffLeftSignal \nBorder \ndetected");
        return 6;
    }
    else if(sensor_data -> cliffFrontRightSignal == 0){
        lcd_printf("cliffFrontRightSignal \nPitfall \ndetected");
        return 7;
    }
    else if(sensor_data -> cliffFrontRightSignal > 1000){
        lcd_printf("cliffFrontRightSignal \nBorder \ndetected");
        return 8;
    }
    else if(sensor_data -> cliffFrontLeftSignal == 0){
        lcd_printf("cliffFrontLeftSignal \nPitfall \ndetected");
        return 9;
    }
    else if(sensor_data -> cliffFrontLeftSignal > 1000){
        lcd_printf("cliffFrontLeftSignal \nBorder \ndetected");
        return 10;
    }
    return 0;
}

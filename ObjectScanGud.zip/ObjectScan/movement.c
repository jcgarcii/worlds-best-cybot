/*
 * movement.c
 *
 *  Created on: Feb 9, 2021
 *      Author: jmhafele
 */

#include "movement.h"

int num_checkpoints = 18; //Number of checkpoints
int checkpoints[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; //If 0, hasnt/cant reach checkpoint on field
int current_checkpoint = 0;

double move_forward(oi_t *sensor_data, double distance_mm){

    double sum = 0;
    oi_setWheels(250,250);
    while(sum < distance_mm){
        oi_update(sensor_data);
        sum += sensor_data -> distance;//use -> notation since pointer

        if(check_sensors(sensor_data) == 1 || check_sensors(sensor_data) == 2){ //Checks if robot had collision on either bumper
            oi_setWheels(0,0); //Stop
            move_backward(sensor_data, sum); //backs up, states specific checkpoint unreachable
            checkpoints[current_checkpoint + 1] = 0;
            return sum;
        }

    }
    oi_setWheels(0,0); //Stop
    lcd_printf("distance = %.2f meters", sum/1000); //Prints distance
    checkpoints[current_checkpoint + 1] = 1;
    return sum;
}

double turn_right(oi_t *sensor, double degrees){
    double angle = 0;
    oi_setWheels(50,-50);
    while(angle < degrees - 1.4){
        oi_update(sensor);
        angle += sensor -> angle;
    }
    oi_setWheels(0,0); //Stop
    return angle;
}

double turn_left(oi_t *sensor, double degrees){
    double angle = 0;
    oi_setWheels(-50,50);
    while(angle > -degrees + 1.4){
        oi_update(sensor);
        angle += sensor -> angle;
    }
    oi_setWheels(0,0); //Stop
    return angle;
}

double move_backward(oi_t *sensor_data, double distance_mm){

    double sum = 0;

    oi_setWheels(-250,-250);

    while(sum > -distance_mm){
        oi_update(sensor_data);
        sum += sensor_data -> distance;//use -> notation since pointer
    }

    oi_setWheels(0,0); //Stop
    lcd_printf("distance = %.2f meters", sum/1000); //Prints distance
    return sum;
}

int check_sensors(oi_t *sensor_data){
    if(sensor_data -> bumpRight){
        lcd_printf("bumpRight \ndetected");
        return 1;
    }
    else if(sensor_data -> bumpLeft){
        lcd_printf("bumpLeft \ndetected");
        return 2;
    }
    else if(sensor_data -> cliffRight){
        lcd_printf("cliffRight \ndetected");
        return 3;
    }
    else if(sensor_data -> cliffLeft){
        lcd_printf("cliffLeft \ndetected");
        return 4;
    }
    else if(sensor_data -> cliffFrontRight){
        lcd_printf("cliffFrontRight \ndetected");
        return 5;
    }
    else if(sensor_data -> cliffFrontLeft){
        lcd_printf("cliffFrontLeft \ndetected");
        return 6;
    }
    return 0;
}

int track_scan(oi_t *sensor_data, Object objects[]){

    int object_checkpoint = -1;

    current_checkpoint = 0;

    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 600);
    current_checkpoint = 1;


    turn_left(sensor_data, 90);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 600);
    current_checkpoint = 2;

    move_forward(sensor_data, 600);
    current_checkpoint = 3;

    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 600);
    current_checkpoint = 4;

    turn_left(sensor_data, 90);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 600);
    current_checkpoint = 5;

    move_backward(sensor_data, 550);
    turn_left(sensor_data, 90);
    move_forward(sensor_data, 550);
    turn_left(sensor_data, 90);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 600);
    current_checkpoint = 6;

    lcd_printf("%d", checkpoints[6]);

    if(!checkpoints[6]){
        return -1;
    }

    move_forward(sensor_data, 600);
    current_checkpoint = 7;

    turn_left(sensor_data, 90);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 550);
    current_checkpoint = 8;
    move_backward(sensor_data, 550);

    turn_right(sensor_data, 180);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 550);
    current_checkpoint = 9;

    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 550);
    current_checkpoint = 10;
    move_backward(sensor_data, 500);

    turn_left(sensor_data, 90);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 600);
    current_checkpoint = 11;

    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 600);
    current_checkpoint = 12;

    turn_right(sensor_data, 90);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 550);
    current_checkpoint = 13;
    move_backward(sensor_data, 550);

    turn_right(sensor_data, 180);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 550);
    current_checkpoint = 14;

    move_forward(sensor_data, 550);
    current_checkpoint = 15;
    move_backward(sensor_data, 550);

    turn_right(sensor_data, 90);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 550);
    current_checkpoint = 16;

    turn_right(sensor_data, 90);
    object_scan(objects); //Scans objects in 180 degrees
    move_forward(sensor_data, 550);
    current_checkpoint = 17;

    return -1;
}

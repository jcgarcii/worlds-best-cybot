
libcybotScan.txt is a pre-compiled library for CyBot sensor scanning. 

The file extension must be changed from .txt to .lib after copying into your folder.
/*
 * movement.h
 *
 *  Created on: Feb 9, 2021
 *      Author: jmhafele
 */

#ifndef MOVEMENT_H_
#define MOVEMENT_H_

#include "open_interface.h"
#include "lcd.h"
#include "object.h"

//moves cybot strictly forward, no fluff
double move_forward(oi_t *sensor_data, double distance_mm);

//Turns cybot right x degrees
double turn_right(oi_t *sensor, double degrees);

//turns cybot left x degrees
double turn_left(oi_t *sensor, double degrees);

//moves cybot strictly backward, no fluff
double move_backward(oi_t *sensor_data, double distance_mm);

//checks open interface sensors
int check_sensors(oi_t *sensor_data);

//Scans the whole track for desired object, marks checkpoints. Returns int where which scanning
int track_scan(oi_t *sensor_data, Object objects[]);

#endif /* MOVEMENT_H_ */

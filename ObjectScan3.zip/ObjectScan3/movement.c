/*
 * movement.c
 *
 *  Created on: Feb 9, 2021
 *      Author: jmhafele
 */

#include "movement.h"

bool foundPit = false;
bool noPitStop = false;
bool hitPitCorner = false;
int pitTurnState = 0; //1 if turns left initially, 2 if turns right initially after wall bounce, default 1 if never hits wall

double move_forward(oi_t *sensor_data, double distance_mm){

    double sum = 0;
    oi_setWheels(250,250);
    while(sum < distance_mm){
        oi_update(sensor_data);
        sum += sensor_data -> distance;//use -> notation since pointer

        if(check_sensors(sensor_data)){ //Checks if robot had collision
            oi_setWheels(0,0); //Stop
            move_backward(sensor_data, sum); //backs up, states specific checkpoint unreachable
            return sum;
        }

    }
    oi_setWheels(0,0); //Stop
    lcd_printf("distance = %.2f meters", sum/1000); //Prints distance
    return sum;
}

double move_forward_isle(oi_t *sensor_data, double distance_mm){

    double sum = 0;
    oi_setWheels(250,250);
    //scan if tall object in way
    //handle moving around tall object before total move, maybe a while loop until finished?
    while(sum < distance_mm){
        oi_update(sensor_data);
        sum += sensor_data -> distance;//use -> notation since pointer
        int sensor = check_sensors(sensor_data);
        if(sensor == 4 || sensor == 8){ //Checks if robot hit border on right side so it can start going around edge
            move_backward(sensor_data, 25);
//            turn_left(sensor_data, 90);
            if(pitTurnState == 2){
                turn_left(sensor_data, 120);
                hitPitCorner = true;
            }
            else if(pitTurnState == 1){
                turn_right(sensor_data, 120);
                hitPitCorner = true;
            }
            else {
                turn_left(sensor_data, 90);
            }
            noPitStop = false;
            return sum;
        }
        if(sensor == 6 ||sensor == 10){ //Checks if robot hit border on left side so it can start going around edge
            move_backward(sensor_data, 25);
//            turn_right(sensor_data, 90);
            if(pitTurnState == 2){
                turn_left(sensor_data, 120);
                hitPitCorner = true;
            }
            else if(pitTurnState == 1){
                turn_right(sensor_data, 120);
                hitPitCorner = true;
            }
            else {
                turn_right(sensor_data, 90);
            }
            noPitStop = false;
            return sum;
        }
        else if(sensor == 3 || sensor == 7){ //Checks if robot hit pitfall on right side, needs to orient now and get ready to find isle to stop in
            move_backward(sensor_data, 50);
            if(foundPit){
                turn_left(sensor_data, 5);
            }
            pitTurnState = 1;
            foundPit = true;
            noPitStop = false;
            return sum;
        }
        else if(sensor == 5 ||sensor == 9){ //Checks if robot hit pitfall on left side, needs to orient now and get ready to find isle to stop in
            move_backward(sensor_data, 50);
            if(foundPit){
                turn_right(sensor_data, 5);
            }
            pitTurnState = 2;
            foundPit = true;
            noPitStop = false;
            return sum;
        }
        else if(sensor == 1 || sensor == 2){ //Bumped into low object, need to go around
            avoid_short(sensor_data);
            return sum;
        }
        noPitStop = true;
    }
    oi_setWheels(0,0); //Stop
    lcd_printf("distance = %.2f meters", sum/1000); //Prints distance
    return sum;
}

double turn_right(oi_t *sensor, double degrees){
    double angle = 0;
    oi_setWheels(50,-50);
    while(angle < degrees - 1.4){
        oi_update(sensor);
        angle += sensor -> angle;
    }
    oi_setWheels(0,0); //Stop
    return angle;
}

double turn_left(oi_t *sensor, double degrees){
    double angle = 0;
    oi_setWheels(-50,50);
    while(angle > -degrees + 1.4){
        oi_update(sensor);
        angle += sensor -> angle;
    }
    oi_setWheels(0,0); //Stop
    return angle;
}

double move_backward(oi_t *sensor_data, double distance_mm){

    double sum = 0;

    oi_setWheels(-250,-250);

    while(sum > -distance_mm){
        oi_update(sensor_data);
        sum += sensor_data -> distance;//use -> notation since pointer
    }

    oi_setWheels(0,0); //Stop
    lcd_printf("distance = %.2f meters", sum/1000); //Prints distance
    return sum;
}

void avoid_short(oi_t *sensor_data){

    if(sensor_data -> bumpRight){
        move_backward(sensor_data, 100);
        turn_left(sensor_data, 90);
        move_forward_isle(sensor_data, 200);
        turn_right(sensor_data, 90);
        move_forward_isle(sensor_data, 100);
    }

    else if(sensor_data -> bumpLeft){
        move_backward(sensor_data, 100);
        turn_right(sensor_data, 90);
        move_forward_isle(sensor_data, 200);
        turn_left(sensor_data, 90);
        move_forward_isle(sensor_data, 100);
    }
}

void avoid_tall(Object objects[], int num_objects){

}

int check_sensors(oi_t *sensor_data){
    if(sensor_data -> bumpRight){
        lcd_printf("bumpRight \ndetected");
        return 1;
    }
    else if(sensor_data -> bumpLeft){
        lcd_printf("bumpLeft \ndetected");
        return 2;
    }
    else if(sensor_data -> cliffRightSignal > 1000){
        lcd_printf("cliffRightSignal \nBorder \ndetected");
        return 4;
    }
    else if(sensor_data -> cliffLeftSignal > 1000){
        lcd_printf("cliffLeftSignal \nBorder \ndetected");
        return 6;
    }
    else if(sensor_data -> cliffFrontRightSignal > 1000){
        lcd_printf("cliffFrontRightSignal \nBorder \ndetected");
        return 8;
    }
    else if(sensor_data -> cliffFrontLeftSignal > 1000){
        lcd_printf("cliffFrontLeftSignal \nBorder \ndetected");
        return 10;
    }
    else if(sensor_data -> cliffRightSignal == 0){
        lcd_printf("cliffRightSignal \nPitfall \ndetected");
        return 3;
    }
    else if(sensor_data -> cliffLeftSignal == 0){
        lcd_printf("cliffLeftSignal \nPitfall \ndetected");
        return 5;
    }
    else if(sensor_data -> cliffFrontRightSignal == 0){
        lcd_printf("cliffFrontRightSignal \nPitfall \ndetected");
        return 7;
    }
    else if(sensor_data -> cliffFrontLeftSignal == 0){
        lcd_printf("cliffFrontLeftSignal \nPitfall \ndetected");
        return 9;
    }
    return 0;
}

int go_isle(oi_t *sensor_data, Object objects[]){
    int num_objects = 0;
    int counter = 0;
    turn_left(sensor_data, 180); //Turns around after bumping object
    while(!foundPit){
        move_forward_isle(sensor_data, 1000); //Moves in bursts to collect data as going towards wall
    }
    num_objects = object_scan(objects); //scans to see if in pit or facing away from objects and needs adjustment

    if(pitTurnState == 1){
        if(objects[num_objects - 1].distance > 50){ //If robot is on top of pitfall on right corner
            while(!noPitStop){
                counter++;
                if(counter % 3 == 0){ //Scan check if in isle accidentally
                    num_objects = object_scan(objects);
                    if(objects[0].distance < 50){
                        turn_left(sensor_data, 45);
                        break;
                    }
                }
                move_forward_isle(sensor_data, 400);
                if(noPitStop){//Condition to check if bot is actually stopped in front of pit or not
                    if(hitPitCorner){
                        turn_left(sensor_data, 90);
                    }
                    else {
                        turn_right(sensor_data, 90);
                    }
                    double dist = move_forward(sensor_data, 100);
                    if(dist < 100){ //If robot bumps into pit, needs to keep going farther
                        noPitStop = false;
                        if(hitPitCorner){
                            turn_right(sensor_data, 90);
                        }
                        else {
                            turn_left(sensor_data, 90);
                        }
                    }
                }
            }
            num_objects = object_scan(objects);
        }
        else { //If robot is in isle 3
            turn_left(sensor_data, 45);
        }
        int closest_index = least_distance(objects, num_objects);
        move_forward(sensor_data, objects[closest_index].distance * 10 - 50);
    }
    else if(pitTurnState == 2){
        if(objects[0].distance > 50){ //If robot is on top of pitfall on right corner
            while(!noPitStop){
                counter++;
                if(counter % 3 == 0){ //Scan check if in isle accidentally
                    num_objects = object_scan(objects);
                    if(objects[0].distance < 50){
                        turn_right(sensor_data, 45);
                        break;
                    }
                }
                move_forward_isle(sensor_data, 400);
                if(noPitStop){//Condition to check if bot is actually stopped in front of pit or not
                    if(hitPitCorner){
                        turn_right(sensor_data, 90);
                    }
                    else {
                        turn_left(sensor_data, 90);
                    }
                    double dist = move_forward(sensor_data, 100);
                    if(dist < 100){ //If robot bumps into pit, needs to keep going farther
                        noPitStop = false;
                        if(hitPitCorner){
                            turn_left(sensor_data, 90);
                        }
                        else {
                            turn_right(sensor_data, 90);
                        }
                    }
                }
            }
            num_objects = object_scan(objects);
        }
        else { //If robot is in isle 1
            turn_right(sensor_data, 45);
        }
        int closest_index = least_distance(objects, num_objects);
        move_forward(sensor_data, objects[closest_index].distance * 10 - 50);
    }
    char message[100];
    sprintf(message, "\n\rObject returned, powering down now");
    uart_sendStr(message);
    return -1;
}

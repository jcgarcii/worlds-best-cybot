/*
 * object.c
 *
 *  Created on: Apr 8, 2021
 *      Author: jmhafele
 */

#include "object.h"

void object_init(void){
    servo_init();
    adc_init();
    ping_init();
    servo_calibrate();
}


int object_scan(Object objects[]){
    int ir_cm = 0;
    int ir_cm_previous = 300;
    double ping_cm = 0;
    double object_angle_start = 0;
    double object_angle_stop = 0;
    int object_dist = 0;
    int object_index = 0;

    bool detected_object = false;

    char message[100];
//    sprintf(message, "\n\rDegrees \tIR Dist (cm) \tSonar Dist(cm)");
//    uart_sendStr(message);

    int i;
    for(i = 0; i <= 180; i = i + 2){

        ir_cm = adc_read();
        ping_cm = ping_getDistance();
//        timer_waitMillis(25);
        servo_move(i);
//        sprintf(message, "\n\r%d \t\t%d \t\t%0.2f", i, ir_cm, ping_cm);
//        uart_sendStr(message);

        //Start of object
        if((ir_cm_previous >= ir_cm + 100 || ir_cm_previous <= ir_cm - 100) && !detected_object){
            object_angle_start = i;
            object_dist = ping_cm;
            if(object_dist < 0){
                break;
            }
            detected_object = true;
        }

        //End of object
        else if((ir_cm_previous >= ir_cm + 100 || ir_cm_previous <= ir_cm - 100) && detected_object){
            object_angle_stop = i;
            detected_object = false;

            //process object data
            int object_angle = (object_angle_stop - object_angle_start)/2 + object_angle_start;
            double object_width = 2 * 3.1456 * object_dist * ((object_angle_stop - object_angle_start) / 360);

            //Builds object struct with data processed
            objects[object_index].angle = object_angle;
            objects[object_index].distance = object_dist;
            objects[object_index].width = object_width;

            object_index++;
        }

        ir_cm_previous = ir_cm;

    }
    print_objects(objects, object_index);
    return object_index;
}

void print_objects(Object objects[], int num_objects){

    char putty_message[100];
    char lcd_message[100];
    sprintf(putty_message, "\n\r Index \t Angle \t Distance(cm) \t Width(cm)");
    uart_sendStr(putty_message);

    int i;
    for(i = 0; i < num_objects; i++){
        sprintf(putty_message,"\n\r %d \t %d \t %0.1f \t\t %0.1f", i, objects[i].angle, objects[i].distance, objects[i].width);
        uart_sendStr(putty_message);
        sprintf(lcd_message, "Index: %d \nAngle: %d \nDist(cm): %0.1f \nWidth(cm): %0.1f", i, objects[i].angle, objects[i].distance, objects[i].width);
        lcd_printf(lcd_message);
    }
}

int least_distance(Object objects[], int num_objects){
    int least_index = 0;
    int i;
    for(i = 0; i < num_objects; i++){
        if(objects[i].distance < objects[least_index].distance){
            least_index = i;
        }
    }
    return least_index;
}
